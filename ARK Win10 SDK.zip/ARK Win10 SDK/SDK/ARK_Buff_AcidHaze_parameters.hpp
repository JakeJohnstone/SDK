#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Buff_AcidHaze_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Buff_AcidHaze.Buff_AcidHaze_C.UserConstructionScript
struct ABuff_AcidHaze_C_UserConstructionScript_Params
{
};

// Function Buff_AcidHaze.Buff_AcidHaze_C.ExecuteUbergraph_Buff_AcidHaze
struct ABuff_AcidHaze_C_ExecuteUbergraph_Buff_AcidHaze_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
