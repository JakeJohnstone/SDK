#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Ankylo_Character_BP_Aberrant_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Ankylo_Character_BP_Aberrant.Ankylo_Character_BP_Aberrant_C.UserConstructionScript
struct AAnkylo_Character_BP_Aberrant_C_UserConstructionScript_Params
{
};

// Function Ankylo_Character_BP_Aberrant.Ankylo_Character_BP_Aberrant_C.ExecuteUbergraph_Ankylo_Character_BP_Aberrant
struct AAnkylo_Character_BP_Aberrant_C_ExecuteUbergraph_Ankylo_Character_BP_Aberrant_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
