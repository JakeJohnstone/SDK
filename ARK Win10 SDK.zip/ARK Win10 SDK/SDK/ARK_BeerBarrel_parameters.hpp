#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BeerBarrel_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BeerBarrel.BeerBarrel_C.UserConstructionScript
struct ABeerBarrel_C_UserConstructionScript_Params
{
};

// Function BeerBarrel.BeerBarrel_C.BPUpdateItemVisuals
struct ABeerBarrel_C_BPUpdateItemVisuals_Params
{
};

// Function BeerBarrel.BeerBarrel_C.ExecuteUbergraph_BeerBarrel
struct ABeerBarrel_C_ExecuteUbergraph_BeerBarrel_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
