#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Base_DoubleDoorframe_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Base_DoubleDoorframe.Base_DoubleDoorframe_C.UserConstructionScript
struct ABase_DoubleDoorframe_C_UserConstructionScript_Params
{
};

// Function Base_DoubleDoorframe.Base_DoubleDoorframe_C.ExecuteUbergraph_Base_DoubleDoorframe
struct ABase_DoubleDoorframe_C_ExecuteUbergraph_Base_DoubleDoorframe_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
