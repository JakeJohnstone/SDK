#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Achatina_AIController_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Achatina_AIController.Achatina_AIController_C.UserConstructionScript
struct AAchatina_AIController_C_UserConstructionScript_Params
{
};

// Function Achatina_AIController.Achatina_AIController_C.ExecuteUbergraph_Achatina_AIController
struct AAchatina_AIController_C_ExecuteUbergraph_Achatina_AIController_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
