#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_ArthroSpit_TrailEmitter_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ArthroSpit_TrailEmitter.ArthroSpit_TrailEmitter_C.UserConstructionScript
struct AArthroSpit_TrailEmitter_C_UserConstructionScript_Params
{
};

// Function ArthroSpit_TrailEmitter.ArthroSpit_TrailEmitter_C.ExecuteUbergraph_ArthroSpit_TrailEmitter
struct AArthroSpit_TrailEmitter_C_ExecuteUbergraph_ArthroSpit_TrailEmitter_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
