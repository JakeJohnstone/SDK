#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Anklyo-Anim-Blueprint_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Anklyo-Anim-Blueprint.Anklyo-Anim-Blueprint_C.ExecuteUbergraph_Anklyo-Anim-Blueprint
struct UAnklyo_Anim_Blueprint_C_ExecuteUbergraph_Anklyo_Anim_Blueprint_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
