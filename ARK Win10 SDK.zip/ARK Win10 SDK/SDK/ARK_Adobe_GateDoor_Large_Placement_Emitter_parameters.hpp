#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Adobe_GateDoor_Large_Placement_Emitter_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Adobe_GateDoor_Large_Placement_Emitter.Adobe_GateDoor_Large_Placement_Emitter_C.UserConstructionScript
struct AAdobe_GateDoor_Large_Placement_Emitter_C_UserConstructionScript_Params
{
};

// Function Adobe_GateDoor_Large_Placement_Emitter.Adobe_GateDoor_Large_Placement_Emitter_C.ExecuteUbergraph_Adobe_GateDoor_Large_Placement_Emitter
struct AAdobe_GateDoor_Large_Placement_Emitter_C_ExecuteUbergraph_Adobe_GateDoor_Large_Placement_Emitter_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
