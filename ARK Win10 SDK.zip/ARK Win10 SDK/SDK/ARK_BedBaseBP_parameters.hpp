#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BedBaseBP_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BedBaseBP.BedBaseBP_C.UserConstructionScript
struct ABedBaseBP_C_UserConstructionScript_Params
{
};

// Function BedBaseBP.BedBaseBP_C.ExecuteUbergraph_BedBaseBP
struct ABedBaseBP_C_ExecuteUbergraph_BedBaseBP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
