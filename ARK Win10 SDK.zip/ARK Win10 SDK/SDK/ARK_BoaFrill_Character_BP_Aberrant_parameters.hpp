#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BoaFrill_Character_BP_Aberrant_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BoaFrill_Character_BP_Aberrant.BoaFrill_Character_BP_Aberrant_C.UserConstructionScript
struct ABoaFrill_Character_BP_Aberrant_C_UserConstructionScript_Params
{
};

// Function BoaFrill_Character_BP_Aberrant.BoaFrill_Character_BP_Aberrant_C.ExecuteUbergraph_BoaFrill_Character_BP_Aberrant
struct ABoaFrill_Character_BP_Aberrant_C_ExecuteUbergraph_BoaFrill_Character_BP_Aberrant_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
