#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Bigfoot_Anim_Blueprint_Zipline_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Bigfoot_Anim_Blueprint_Zipline.Bigfoot_Anim_Blueprint_Zipline_C.ExecuteUbergraph_Bigfoot_Anim_Blueprint_Zipline
struct UBigfoot_Anim_Blueprint_Zipline_C_ExecuteUbergraph_Bigfoot_Anim_Blueprint_Zipline_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
