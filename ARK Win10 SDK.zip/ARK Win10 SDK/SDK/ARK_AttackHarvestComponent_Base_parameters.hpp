#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_AttackHarvestComponent_Base_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AttackHarvestComponent_Base.AttackHarvestComponent_Base_C.ExecuteUbergraph_AttackHarvestComponent_Base
struct UAttackHarvestComponent_Base_C_ExecuteUbergraph_AttackHarvestComponent_Base_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
