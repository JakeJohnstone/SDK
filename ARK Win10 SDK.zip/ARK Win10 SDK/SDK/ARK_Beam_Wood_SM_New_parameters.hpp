#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Beam_Wood_SM_New_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Beam_Wood_SM_New.Beam_Wood_SM_New_C.UserConstructionScript
struct ABeam_Wood_SM_New_C_UserConstructionScript_Params
{
};

// Function Beam_Wood_SM_New.Beam_Wood_SM_New_C.ExecuteUbergraph_Beam_Wood_SM_New
struct ABeam_Wood_SM_New_C_ExecuteUbergraph_Beam_Wood_SM_New_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
