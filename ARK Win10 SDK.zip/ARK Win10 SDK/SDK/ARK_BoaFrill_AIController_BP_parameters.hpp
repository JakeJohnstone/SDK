#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BoaFrill_AIController_BP_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BoaFrill_AIController_BP.BoaFrill_AIController_BP_C.UserConstructionScript
struct ABoaFrill_AIController_BP_C_UserConstructionScript_Params
{
};

// Function BoaFrill_AIController_BP.BoaFrill_AIController_BP_C.ExecuteUbergraph_BoaFrill_AIController_BP
struct ABoaFrill_AIController_BP_C_ExecuteUbergraph_BoaFrill_AIController_BP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
