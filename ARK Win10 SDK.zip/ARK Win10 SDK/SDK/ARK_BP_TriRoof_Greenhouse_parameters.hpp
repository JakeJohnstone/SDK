#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BP_TriRoof_Greenhouse_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_TriRoof_Greenhouse.BP_TriRoof_Greenhouse_C.UserConstructionScript
struct ABP_TriRoof_Greenhouse_C_UserConstructionScript_Params
{
};

// Function BP_TriRoof_Greenhouse.BP_TriRoof_Greenhouse_C.ExecuteUbergraph_BP_TriRoof_Greenhouse
struct ABP_TriRoof_Greenhouse_C_ExecuteUbergraph_BP_TriRoof_Greenhouse_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
