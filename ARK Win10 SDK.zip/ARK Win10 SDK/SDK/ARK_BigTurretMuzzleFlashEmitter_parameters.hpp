#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BigTurretMuzzleFlashEmitter_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BigTurretMuzzleFlashEmitter.BigTurretMuzzleFlashEmitter_C.UserConstructionScript
struct ABigTurretMuzzleFlashEmitter_C_UserConstructionScript_Params
{
};

// Function BigTurretMuzzleFlashEmitter.BigTurretMuzzleFlashEmitter_C.ExecuteUbergraph_BigTurretMuzzleFlashEmitter
struct ABigTurretMuzzleFlashEmitter_C_ExecuteUbergraph_BigTurretMuzzleFlashEmitter_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
