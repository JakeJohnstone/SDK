#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BoobyTrapHumanAnimBP_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BoobyTrapHumanAnimBP.BoobyTrapHumanAnimBP_C.ExecuteUbergraph_BoobyTrapHumanAnimBP
struct UBoobyTrapHumanAnimBP_C_ExecuteUbergraph_BoobyTrapHumanAnimBP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
