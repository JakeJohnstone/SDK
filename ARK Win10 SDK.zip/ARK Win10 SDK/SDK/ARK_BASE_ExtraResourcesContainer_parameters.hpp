#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BASE_ExtraResourcesContainer_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BASE_ExtraResourcesContainer.BASE_ExtraResourcesContainer_C.ExecuteUbergraph_BASE_ExtraResourcesContainer
struct UBASE_ExtraResourcesContainer_C_ExecuteUbergraph_BASE_ExtraResourcesContainer_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
