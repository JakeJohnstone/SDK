#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Ankylo_AIController_BP_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Ankylo_AIController_BP.Ankylo_AIController_BP_C.UserConstructionScript
struct AAnkylo_AIController_BP_C_UserConstructionScript_Params
{
};

// Function Ankylo_AIController_BP.Ankylo_AIController_BP_C.ExecuteUbergraph_Ankylo_AIController_BP
struct AAnkylo_AIController_BP_C_ExecuteUbergraph_Ankylo_AIController_BP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
