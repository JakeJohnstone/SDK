#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BearTrap_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BearTrap.BearTrap_C.UserConstructionScript
struct ABearTrap_C_UserConstructionScript_Params
{
};

// Function BearTrap.BearTrap_C.ExecuteUbergraph_BearTrap
struct ABearTrap_C_ExecuteUbergraph_BearTrap_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
