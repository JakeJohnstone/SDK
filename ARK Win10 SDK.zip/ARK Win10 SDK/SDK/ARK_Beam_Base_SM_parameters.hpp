#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Beam_Base_SM_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Beam_Base_SM.Beam_Base_SM_C.UserConstructionScript
struct ABeam_Base_SM_C_UserConstructionScript_Params
{
};

// Function Beam_Base_SM.Beam_Base_SM_C.ExecuteUbergraph_Beam_Base_SM
struct ABeam_Base_SM_C_ExecuteUbergraph_Beam_Base_SM_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
