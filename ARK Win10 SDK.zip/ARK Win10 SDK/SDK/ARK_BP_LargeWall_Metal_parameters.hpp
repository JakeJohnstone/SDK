#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BP_LargeWall_Metal_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_LargeWall_Metal.BP_LargeWall_Metal_C.UserConstructionScript
struct ABP_LargeWall_Metal_C_UserConstructionScript_Params
{
};

// Function BP_LargeWall_Metal.BP_LargeWall_Metal_C.ExecuteUbergraph_BP_LargeWall_Metal
struct ABP_LargeWall_Metal_C_ExecuteUbergraph_BP_LargeWall_Metal_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
