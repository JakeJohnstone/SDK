#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BoobyTrapFemaleAnimBP_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BoobyTrapFemaleAnimBP.BoobyTrapFemaleAnimBP_C.ExecuteUbergraph_BoobyTrapFemaleAnimBP
struct UBoobyTrapFemaleAnimBP_C_ExecuteUbergraph_BoobyTrapFemaleAnimBP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
