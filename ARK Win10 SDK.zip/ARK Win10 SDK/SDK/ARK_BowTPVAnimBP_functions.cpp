// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BowTPVAnimBP_parameters.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BowTPVAnimBP.BowTPVAnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_BowTPVAnimBP_AnimGraphNode_TransitionResult_F2F53E764A3F2C241F66ABA5198D1BD1
// ()

void UBowTPVAnimBP_C::EvaluateGraphExposedInputs_ExecuteUbergraph_BowTPVAnimBP_AnimGraphNode_TransitionResult_F2F53E764A3F2C241F66ABA5198D1BD1()
{
	static auto fn = UObject::FindObject<UFunction>("Function BowTPVAnimBP.BowTPVAnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_BowTPVAnimBP_AnimGraphNode_TransitionResult_F2F53E764A3F2C241F66ABA5198D1BD1");

	UBowTPVAnimBP_C_EvaluateGraphExposedInputs_ExecuteUbergraph_BowTPVAnimBP_AnimGraphNode_TransitionResult_F2F53E764A3F2C241F66ABA5198D1BD1_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BowTPVAnimBP.BowTPVAnimBP_C.BlueprintUpdateAnimation
// ()
// Parameters:
// float*                         DeltaTimeX                     (Parm, ZeroConstructor, IsPlainOldData)

void UBowTPVAnimBP_C::BlueprintUpdateAnimation(float* DeltaTimeX)
{
	static auto fn = UObject::FindObject<UFunction>("Function BowTPVAnimBP.BowTPVAnimBP_C.BlueprintUpdateAnimation");

	UBowTPVAnimBP_C_BlueprintUpdateAnimation_Params params;
	params.DeltaTimeX = DeltaTimeX;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BowTPVAnimBP.BowTPVAnimBP_C.ExecuteUbergraph_BowTPVAnimBP
// ()
// Parameters:
// int                            EntryPoint                     (Parm, ZeroConstructor, IsPlainOldData)

void UBowTPVAnimBP_C::ExecuteUbergraph_BowTPVAnimBP(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function BowTPVAnimBP.BowTPVAnimBP_C.ExecuteUbergraph_BowTPVAnimBP");

	UBowTPVAnimBP_C_ExecuteUbergraph_BowTPVAnimBP_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
