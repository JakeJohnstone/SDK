#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Achatina_Character_BP_Aberrant_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Achatina_Character_BP_Aberrant.Achatina_Character_BP_Aberrant_C.UserConstructionScript
struct AAchatina_Character_BP_Aberrant_C_UserConstructionScript_Params
{
};

// Function Achatina_Character_BP_Aberrant.Achatina_Character_BP_Aberrant_C.ExecuteUbergraph_Achatina_Character_BP_Aberrant
struct AAchatina_Character_BP_Aberrant_C_ExecuteUbergraph_Achatina_Character_BP_Aberrant_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
