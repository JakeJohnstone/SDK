#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Base_Wall_Large_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Base_Wall_Large.Base_Wall_Large_C.UserConstructionScript
struct ABase_Wall_Large_C_UserConstructionScript_Params
{
};

// Function Base_Wall_Large.Base_Wall_Large_C.ExecuteUbergraph_Base_Wall_Large
struct ABase_Wall_Large_C_ExecuteUbergraph_Base_Wall_Large_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
