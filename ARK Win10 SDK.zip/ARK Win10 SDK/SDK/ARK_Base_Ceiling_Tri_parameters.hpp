#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Base_Ceiling_Tri_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Base_Ceiling_Tri.Base_Ceiling_Tri_C.UserConstructionScript
struct ABase_Ceiling_Tri_C_UserConstructionScript_Params
{
};

// Function Base_Ceiling_Tri.Base_Ceiling_Tri_C.ExecuteUbergraph_Base_Ceiling_Tri
struct ABase_Ceiling_Tri_C_ExecuteUbergraph_Base_Ceiling_Tri_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
