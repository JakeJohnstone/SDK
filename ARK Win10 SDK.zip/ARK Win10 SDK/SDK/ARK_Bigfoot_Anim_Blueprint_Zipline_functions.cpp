// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Bigfoot_Anim_Blueprint_Zipline_parameters.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Bigfoot_Anim_Blueprint_Zipline.Bigfoot_Anim_Blueprint_Zipline_C.ExecuteUbergraph_Bigfoot_Anim_Blueprint_Zipline
// ()
// Parameters:
// int                            EntryPoint                     (Parm, ZeroConstructor, IsPlainOldData)

void UBigfoot_Anim_Blueprint_Zipline_C::ExecuteUbergraph_Bigfoot_Anim_Blueprint_Zipline(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function Bigfoot_Anim_Blueprint_Zipline.Bigfoot_Anim_Blueprint_Zipline_C.ExecuteUbergraph_Bigfoot_Anim_Blueprint_Zipline");

	UBigfoot_Anim_Blueprint_Zipline_C_ExecuteUbergraph_Bigfoot_Anim_Blueprint_Zipline_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
