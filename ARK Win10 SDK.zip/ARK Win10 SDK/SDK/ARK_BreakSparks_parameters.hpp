#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BreakSparks_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BreakSparks.BreakSparks_C.UserConstructionScript
struct ABreakSparks_C_UserConstructionScript_Params
{
};

// Function BreakSparks.BreakSparks_C.ExecuteUbergraph_BreakSparks
struct ABreakSparks_C_ExecuteUbergraph_BreakSparks_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
