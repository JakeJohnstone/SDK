#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Bigfoot_AIController_BP_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Bigfoot_AIController_BP.Bigfoot_AIController_BP_C.UserConstructionScript
struct ABigfoot_AIController_BP_C_UserConstructionScript_Params
{
};

// Function Bigfoot_AIController_BP.Bigfoot_AIController_BP_C.ExecuteUbergraph_Bigfoot_AIController_BP
struct ABigfoot_AIController_BP_C_ExecuteUbergraph_Bigfoot_AIController_BP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
