#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BoaFrill_AnimBlueprint_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BoaFrill_AnimBlueprint.BoaFrill_AnimBlueprint_C.ExecuteUbergraph_BoaFrill_AnimBlueprint
struct UBoaFrill_AnimBlueprint_C_ExecuteUbergraph_BoaFrill_AnimBlueprint_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
