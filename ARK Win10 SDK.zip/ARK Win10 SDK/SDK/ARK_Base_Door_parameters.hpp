#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Base_Door_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Base_Door.Base_Door_C.UserConstructionScript
struct ABase_Door_C_UserConstructionScript_Params
{
};

// Function Base_Door.Base_Door_C.ExecuteUbergraph_Base_Door
struct ABase_Door_C_ExecuteUbergraph_Base_Door_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
