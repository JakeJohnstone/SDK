#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BowTPVAnimBP_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BowTPVAnimBP.BowTPVAnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_BowTPVAnimBP_AnimGraphNode_TransitionResult_F2F53E764A3F2C241F66ABA5198D1BD1
struct UBowTPVAnimBP_C_EvaluateGraphExposedInputs_ExecuteUbergraph_BowTPVAnimBP_AnimGraphNode_TransitionResult_F2F53E764A3F2C241F66ABA5198D1BD1_Params
{
};

// Function BowTPVAnimBP.BowTPVAnimBP_C.BlueprintUpdateAnimation
struct UBowTPVAnimBP_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BowTPVAnimBP.BowTPVAnimBP_C.ExecuteUbergraph_BowTPVAnimBP
struct UBowTPVAnimBP_C_ExecuteUbergraph_BowTPVAnimBP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
