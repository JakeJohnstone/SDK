#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BP_Emitter_Master_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_Emitter_Master.BP_Emitter_Master_C.UserConstructionScript
struct ABP_Emitter_Master_C_UserConstructionScript_Params
{
};

// Function BP_Emitter_Master.BP_Emitter_Master_C.ExecuteUbergraph_BP_Emitter_Master
struct ABP_Emitter_Master_C_ExecuteUbergraph_BP_Emitter_Master_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
