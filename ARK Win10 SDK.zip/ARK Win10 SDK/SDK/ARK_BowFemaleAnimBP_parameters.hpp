#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BowFemaleAnimBP_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BowFemaleAnimBP.BowFemaleAnimBP_C.ExecuteUbergraph_BowFemaleAnimBP
struct UBowFemaleAnimBP_C_ExecuteUbergraph_BowFemaleAnimBP_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
