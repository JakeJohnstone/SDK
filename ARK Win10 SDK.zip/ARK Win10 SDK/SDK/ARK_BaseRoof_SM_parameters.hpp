#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BaseRoof_SM_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BaseRoof_SM.BaseRoof_SM_C.UserConstructionScript
struct ABaseRoof_SM_C_UserConstructionScript_Params
{
};

// Function BaseRoof_SM.BaseRoof_SM_C.ExecuteUbergraph_BaseRoof_SM
struct ABaseRoof_SM_C_ExecuteUbergraph_BaseRoof_SM_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
