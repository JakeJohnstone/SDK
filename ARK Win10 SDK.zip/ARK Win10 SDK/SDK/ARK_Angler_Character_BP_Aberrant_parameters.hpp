#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Angler_Character_BP_Aberrant_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Angler_Character_BP_Aberrant.Angler_Character_BP_Aberrant_C.UserConstructionScript
struct AAngler_Character_BP_Aberrant_C_UserConstructionScript_Params
{
};

// Function Angler_Character_BP_Aberrant.Angler_Character_BP_Aberrant_C.ExecuteUbergraph_Angler_Character_BP_Aberrant
struct AAngler_Character_BP_Aberrant_C_ExecuteUbergraph_Angler_Character_BP_Aberrant_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
