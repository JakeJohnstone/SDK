#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BearTrapLarge_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BearTrapLarge.BearTrapLarge_C.UserConstructionScript
struct ABearTrapLarge_C_UserConstructionScript_Params
{
};

// Function BearTrapLarge.BearTrapLarge_C.ExecuteUbergraph_BearTrapLarge
struct ABearTrapLarge_C_ExecuteUbergraph_BearTrapLarge_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
