#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_Base_Wire_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Base_Wire.Base_Wire_C.UserConstructionScript
struct ABase_Wire_C_UserConstructionScript_Params
{
};

// Function Base_Wire.Base_Wire_C.ExecuteUbergraph_Base_Wire
struct ABase_Wire_C_ExecuteUbergraph_Base_Wire_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
