#pragma once

// ARK (291.0) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARK_BaseWall_Sloped_Left_SM_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BaseWall_Sloped_Left_SM.BaseWall_Sloped_Left_SM_C.UserConstructionScript
struct ABaseWall_Sloped_Left_SM_C_UserConstructionScript_Params
{
};

// Function BaseWall_Sloped_Left_SM.BaseWall_Sloped_Left_SM_C.ExecuteUbergraph_BaseWall_Sloped_Left_SM
struct ABaseWall_Sloped_Left_SM_C_ExecuteUbergraph_BaseWall_Sloped_Left_SM_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
